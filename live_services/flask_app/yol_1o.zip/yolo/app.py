from flask import Flask, render_template, request, jsonify, send_file, session
from ultralytics import YOLO
from ultralytics.utils import ROOT
from PIL import Image
import io
import base64
import numpy as np
import cv2
import os
from collections import defaultdict
from werkzeug.utils import secure_filename
import uuid
import time

app = Flask(__name__, static_folder='static', static_url_path='/static')
app.config['SECRET_KEY'] = 'your-secret-key-change-this-in-production'
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max file size

# ===================== CONFIGURATION =====================
MODEL_PATH = "path/to/your/best.pt"  # CHANGE THIS TO YOUR MODEL PATH
TRACKER_CFG = str(ROOT / "cfg/trackers/bytetrack.yaml")
CONF_THRESHOLD = 0.25
IOU_THRESHOLD = 0.45
IMGSZ = 640
DEVICE = "0"  # Use "cpu" or "0" for GPU
# =========================================================

# Create necessary directories
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Load model once at startup
print(f"Loading YOLO model from: {MODEL_PATH}")
model = YOLO(MODEL_PATH)
print("Model loaded successfully!")

# Store processing status
processing_status = {}


def cleanup_old_files():
    """Clean up files older than 1 hour to save disk space"""
    current_time = time.time()
    for folder in [UPLOAD_FOLDER, OUTPUT_FOLDER]:
        for filename in os.listdir(folder):
            filepath = os.path.join(folder, filename)
            if os.path.isfile(filepath):
                if current_time - os.path.getctime(filepath) > 3600:  # 1 hour
                    try:
                        os.remove(filepath)
                    except:
                        pass


def pil_bytes_to_bgr_numpy(image_bytes: bytes):
    """Load image bytes into BGR numpy (OpenCV)"""
    pil = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    arr = np.array(pil)
    bgr = arr[..., ::-1].copy()
    return bgr


def numpy_img_to_data_uri(img_np: np.ndarray, fmt="png"):
    """Convert numpy image (RGB) to data URI"""
    pil = Image.fromarray(img_np)
    buf = io.BytesIO()
    pil.save(buf, format=fmt.upper())
    buf.seek(0)
    data = base64.b64encode(buf.read()).decode("utf-8")
    return f"data:image/{fmt};base64,{data}"


@app.route("/")
def index():
    cleanup_old_files()
    return render_template("index.html")


@app.route("/predict_image", methods=["POST"])
def predict_image():
    """Handle image detection"""
    if "image" not in request.files:
        return jsonify({"error": "No image provided"}), 400

    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    try:
        # Read and process image
        img_bytes = file.read()
        img_bgr = pil_bytes_to_bgr_numpy(img_bytes)

        # Run inference
        results = model(img_bgr, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, imgsz=IMGSZ)
        res = results[0]

        # Get annotated image
        annotated = res.plot()
        display_img = annotated[..., ::-1]  # BGR to RGB

        # Convert to data URI
        data_uri = numpy_img_to_data_uri(display_img, fmt="png")

        # Extract predictions
        detections = []
        boxes = res.boxes
        if boxes is not None and len(boxes) > 0:
            cls_vals = boxes.cls.tolist() if hasattr(boxes.cls, 'tolist') else [int(x) for x in boxes.cls]
            conf_vals = boxes.conf.tolist() if hasattr(boxes.conf, 'tolist') else [float(x) for x in boxes.conf]
            
            for c, cf in zip(cls_vals, conf_vals):
                name = model.names.get(int(c), str(c))
                detections.append({
                    "class": name,
                    "confidence": float(cf)
                })

        return jsonify({
            "success": True,
            "image": data_uri,
            "detections": detections,
            "total_detections": len(detections)
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/predict_video", methods=["POST"])
def predict_video():
    """Handle video detection (simple)"""
    if "video" not in request.files:
        return jsonify({"error": "No video provided"}), 400

    file = request.files["video"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    try:
        # Generate unique filename
        unique_id = str(uuid.uuid4())
        input_filename = f"{unique_id}_input.mp4"
        output_filename = f"{unique_id}_output.mp4"
        input_path = os.path.join(UPLOAD_FOLDER, input_filename)
        output_path = os.path.join(OUTPUT_FOLDER, output_filename)

        # Save uploaded video
        file.save(input_path)

        # Initialize status
        session_id = unique_id
        processing_status[session_id] = {
            "progress": 0,
            "status": "processing",
            "current_frame": 0,
            "total_frames": 0
        }

        # Get video info
        cap = cv2.VideoCapture(input_path)
        fps = int(cap.get(cv2.CAP_PROP_FPS)) or 30
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()

        processing_status[session_id]["total_frames"] = total_frames

        # Process video
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        # Run detection on video
        results = model(input_path, stream=True, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, imgsz=IMGSZ, verbose=False)

        frame_count = 0
        for result in results:
            frame = result.plot()
            out.write(frame)
            frame_count += 1
            
            # Update progress
            progress = int((frame_count / total_frames) * 100)
            processing_status[session_id]["progress"] = progress
            processing_status[session_id]["current_frame"] = frame_count

        out.release()
        processing_status[session_id]["status"] = "completed"

        return jsonify({
            "success": True,
            "session_id": session_id,
            "output_filename": output_filename,
            "total_frames": total_frames
        })

    except Exception as e:
        if session_id in processing_status:
            processing_status[session_id]["status"] = "error"
        return jsonify({"error": str(e)}), 500


@app.route("/predict_video_counting", methods=["POST"])
def predict_video_counting():
    """Handle video detection with ByteTrack counting"""
    if "video" not in request.files:
        return jsonify({"error": "No video provided"}), 400

    file = request.files["video"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    try:
        # Generate unique filename
        unique_id = str(uuid.uuid4())
        input_filename = f"{unique_id}_input.mp4"
        output_filename = f"{unique_id}_counting.mp4"
        input_path = os.path.join(UPLOAD_FOLDER, input_filename)
        output_path = os.path.join(OUTPUT_FOLDER, output_filename)

        # Save uploaded video
        file.save(input_path)

        # Initialize status
        session_id = unique_id
        processing_status[session_id] = {
            "progress": 0,
            "status": "processing",
            "current_frame": 0,
            "total_frames": 0,
            "unique_objects": 0
        }

        # Get video info
        cap = cv2.VideoCapture(input_path)
        fps = int(cap.get(cv2.CAP_PROP_FPS)) or 30
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()

        processing_status[session_id]["total_frames"] = total_frames

        # Counters for tracking
        seen_ids_global = set()
        seen_ids_per_class = defaultdict(set)

        # Setup video writer
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

        # Run tracking with ByteTrack
        results_stream = model.track(
            source=input_path,
            tracker=TRACKER_CFG,
            stream=True,
            conf=CONF_THRESHOLD,
            iou=IOU_THRESHOLD,
            imgsz=IMGSZ,
            device=DEVICE,
            persist=True,
            verbose=False
        )

        frame_count = 0
        for result in results_stream:
            # Get annotated frame
            frame = result.plot()

            # Update counts using track IDs
            boxes = result.boxes
            if boxes is not None and len(boxes) > 0 and boxes.id is not None:
                ids = boxes.id.int().tolist()
                cls = boxes.cls.int().tolist()
                for tid, c in zip(ids, cls):
                    cname = model.names.get(int(c), str(int(c)))
                    seen_ids_global.add(int(tid))
                    seen_ids_per_class[cname].add(int(tid))

            # Add HUD overlay with counting information
            overlay_height = 40 + (len(seen_ids_per_class) * 30)
            cv2.rectangle(frame, (10, 10), (400, overlay_height), (0, 0, 0), -1)
            
            # Total unique objects
            cv2.putText(frame, f"Total Unique Objects: {len(seen_ids_global)}",
                       (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            # Per-class counts
            y_pos = 70
            for cls_name, ids in sorted(seen_ids_per_class.items(), key=lambda x: len(x[1]), reverse=True):
                cv2.putText(frame, f"{cls_name}: {len(ids)}",
                           (20, y_pos), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                y_pos += 30

            # Write frame
            writer.write(frame)
            frame_count += 1

            # Update progress
            progress = int((frame_count / total_frames) * 100)
            processing_status[session_id]["progress"] = progress
            processing_status[session_id]["current_frame"] = frame_count
            processing_status[session_id]["unique_objects"] = len(seen_ids_global)

        writer.release()
        processing_status[session_id]["status"] = "completed"

        # Get final counts
        class_counts = {cls_name: len(ids) for cls_name, ids in seen_ids_per_class.items()}

        return jsonify({
            "success": True,
            "session_id": session_id,
            "output_filename": output_filename,
            "total_frames": total_frames,
            "unique_objects": len(seen_ids_global),
            "class_counts": class_counts
        })

    except Exception as e:
        if session_id in processing_status:
            processing_status[session_id]["status"] = "error"
        return jsonify({"error": str(e)}), 500


@app.route("/progress/<session_id>")
def get_progress(session_id):
    """Get processing progress for a session"""
    if session_id in processing_status:
        return jsonify(processing_status[session_id])
    return jsonify({"error": "Session not found"}), 404


@app.route("/download/<filename>")
def download_file(filename):
    """Download processed video"""
    try:
        filepath = os.path.join(OUTPUT_FOLDER, filename)
        if os.path.exists(filepath):
            return send_file(filepath, as_attachment=True, download_name=f"detected_{filename}")
        return jsonify({"error": "File not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/view/<filename>")
def view_file(filename):
    """View/stream processed video"""
    try:
        filepath = os.path.join(OUTPUT_FOLDER, filename)
        if os.path.exists(filepath):
            return send_file(filepath, mimetype='video/mp4')
        return jsonify({"error": "File not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("=" * 60)
    print("YOLO Detection Web App")
    print("=" * 60)
    print(f"Model Path: {MODEL_PATH}")
    print(f"Tracker Config: {TRACKER_CFG}")
    print(f"Device: {DEVICE}")
    print("=" * 60)
    print("Starting Flask server...")
    print("Open http://localhost:5000 in your browser")
    print("=" * 60)
    
    # For development - use gunicorn or waitress for production
    app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)
