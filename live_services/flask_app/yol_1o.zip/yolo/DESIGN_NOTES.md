# Design Notes - YOLO Detection System

## Color Scheme

The application uses a clean, professional color palette:

### Primary Colors
- **Primary Blue**: `#2563eb` - Used for buttons, links, and active states
- **Primary Blue Hover**: `#1d4ed8` - Hover state for interactive elements
- **Success Green**: `#10b981` - Success states and positive feedback
- **Danger Red**: `#ef4444` - Error states
- **Warning Orange**: `#f59e0b` - Warning states

### Background Colors
- **Primary Background**: `#ffffff` - White, main content areas
- **Secondary Background**: `#f8fafc` - Light gray, page background
- **Tertiary Background**: `#f1f5f9` - Slightly darker gray, cards

### Text Colors
- **Primary Text**: `#1e293b` - Dark gray, main text
- **Secondary Text**: `#64748b` - Medium gray, descriptions
- **Light Text**: `#94a3b8` - Light gray, disabled states

### Design Principles

1. **Clean & Minimal**: No distracting gradients or excessive colors
2. **Professional**: Uses standard blue as primary color (common in enterprise apps)
3. **High Contrast**: Ensures good readability
4. **Consistent Spacing**: Uses CSS variables for consistent margins/padding
5. **Smooth Transitions**: Subtle animations for better UX
6. **Responsive**: Works on all screen sizes

## Layout Structure

```
Header
  ├── Title
  └── Subtitle

Main Card
  ├── Tabs (3 modes)
  └── Content Area
      ├── Upload Section
      ├── Action Button
      ├── Progress Bar (when processing)
      └── Results Display

Footer
```

## Typography

- **Font Family**: System fonts (-apple-system, BlinkMacSystemFont, Segoe UI, Roboto)
- **Base Font Size**: 16px
- **Headings**: Bold weight (600-700)
- **Body Text**: Regular weight (400)

## Interactive Elements

### Buttons
- Primary action: Blue background
- Hover: Slightly darker blue with subtle lift effect
- Disabled: Gray with reduced opacity

### Upload Areas
- Dashed border by default
- Solid border on hover
- Green background when file is uploaded

### Progress Bars
- Thin, modern design (8px height)
- Blue fill color
- Smooth animation

## Responsive Breakpoints

- **Mobile**: < 480px
- **Tablet**: < 768px
- **Desktop**: > 768px

## File Organization

```
static/
  ├── css/
  │   └── style.css       # All styles in one file
  └── js/
      └── app.js          # Reserved for future JS

templates/
  └── index.html          # Main HTML template
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers

## Accessibility

- Semantic HTML structure
- High contrast ratios
- Clear focus states
- Descriptive labels

## Future Enhancements

Potential improvements for future versions:
1. Dark mode toggle
2. Custom theme colors
3. More animation options
4. Advanced filtering
5. Batch processing UI
6. Real-time camera detection interface

