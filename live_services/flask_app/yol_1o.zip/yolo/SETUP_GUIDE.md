# 🚀 Complete Setup Guide

This guide will walk you through setting up the YOLO Detection Web App step by step.

## 📋 Prerequisites

Before you begin, ensure you have:
- Python 3.8 or higher installed
- pip (Python package installer)
- Your trained YOLO model file (`.pt` file)
- (Optional) CUDA-compatible GPU for faster processing

## 🔧 Step-by-Step Installation

### Step 1: Install Python Dependencies

Open terminal/command prompt in the project directory and run:

```bash
pip install -r requirements.txt
```

This will install all required packages:
- Flask (web framework)
- Ultralytics (YOLO library)
- OpenCV (video processing)
- Pillow (image processing)
- NumPy (numerical operations)

**Note:** This may take 5-10 minutes depending on your internet speed.

### Step 2: Configure Your Model Path

1. Open `app.py` in a text editor
2. Find the configuration section at the top (around line 18):

```python
# ===================== CONFIGURATION =====================
MODEL_PATH = "path/to/your/best.pt"  # CHANGE THIS TO YOUR MODEL PATH
TRACKER_CFG = str(ROOT / "cfg/trackers/bytetrack.yaml")
CONF_THRESHOLD = 0.25
IOU_THRESHOLD = 0.45
IMGSZ = 640
DEVICE = "0"  # Use "cpu" or "0" for GPU
# =========================================================
```

3. Update `MODEL_PATH` with your actual model path

**Examples:**

Windows:
```python
MODEL_PATH = "C:/Users/YourName/Models/best.pt"
```

Linux/Mac:
```python
MODEL_PATH = "/home/username/models/best.pt"
```

Relative path (if model is in project folder):
```python
MODEL_PATH = "models/best.pt"
```

### Step 3: Configure Device Settings

In the same configuration section:

**For GPU (NVIDIA CUDA):**
```python
DEVICE = "0"  # Use first GPU
```

**For CPU:**
```python
DEVICE = "cpu"
```

**For multiple GPUs:**
```python
DEVICE = "0,1"  # Use first two GPUs
```

### Step 4: Adjust Detection Settings (Optional)

You can fine-tune these parameters:

| Parameter | Description | Recommended Range |
|-----------|-------------|-------------------|
| `CONF_THRESHOLD` | Minimum confidence for detection | 0.20 - 0.50 |
| `IOU_THRESHOLD` | IoU threshold for NMS | 0.40 - 0.50 |
| `IMGSZ` | Input image size | 320, 416, 640, 1280 |

**Tips:**
- Lower `CONF_THRESHOLD` = More detections (may include false positives)
- Higher `CONF_THRESHOLD` = Fewer but more confident detections
- Smaller `IMGSZ` = Faster processing, less accurate
- Larger `IMGSZ` = Slower processing, more accurate

## ▶️ Running the Application

### Windows

**Option 1: Double-click**
- Simply double-click `run.bat`

**Option 2: Command Prompt**
```bash
python app.py
```

### Linux/Mac

**Option 1: Using script**
```bash
chmod +x run.sh
./run.sh
```

**Option 2: Terminal**
```bash
python app.py
```

### Expected Output

You should see:
```
============================================================
YOLO Detection Web App
============================================================
Model Path: path/to/your/best.pt
Tracker Config: .../cfg/trackers/bytetrack.yaml
Device: 0
============================================================
Loading YOLO model from: path/to/your/best.pt
Model loaded successfully!
Starting Flask server...
Open http://localhost:5000 in your browser
============================================================
 * Running on http://0.0.0.0:5000
```

## 🌐 Accessing the Application

1. Open your web browser
2. Go to: `http://localhost:5000`
3. You should see the YOLO Detection System interface

## 🎯 Using the Application

### Feature 1: Image Detection

1. Click on **"📸 Image Detection"** tab
2. Click the upload area or drag & drop an image
3. Supported formats: JPG, PNG, JPEG
4. Click **"Detect Objects"**
5. View results with bounding boxes and confidence scores

### Feature 2: Video Detection

1. Click on **"🎥 Video Detection"** tab
2. Upload a video file (MP4, AVI, MOV)
3. Click **"Process Video"**
4. Watch the progress bar (shows current frame / total frames)
5. Once complete, view the processed video
6. Click **"💾 Download Video"** to save the result

### Feature 3: Detection with Counting

1. Click on **"📊 Detection with Counting"** tab
2. Upload a video file
3. Click **"Process with Counting"**
4. Monitor progress and unique object count
5. View statistics:
   - Total unique objects
   - Count per class
6. Watch the annotated video with counting overlay
7. Download the result video

## 🐛 Troubleshooting

### Problem: "Model not found" error

**Solution:**
- Check if `MODEL_PATH` is correct
- Use absolute path instead of relative path
- Ensure the `.pt` file exists at that location

### Problem: "CUDA out of memory" error

**Solutions:**
1. Reduce `IMGSZ` to 416 or 320
2. Switch to CPU: `DEVICE = "cpu"`
3. Process smaller videos
4. Close other GPU-using applications

### Problem: Video processing is very slow

**Solutions:**
1. Use GPU instead of CPU
2. Reduce `IMGSZ` to 416 or 320
3. Reduce video resolution before uploading
4. Use a smaller YOLO model (e.g., YOLOv8n instead of YOLOv8x)

### Problem: Port 5000 already in use

**Solution:**
Edit `app.py`, change the last line:
```python
app.run(host="0.0.0.0", port=8080, debug=True, threaded=True)
```

Then access via `http://localhost:8080`

### Problem: ByteTrack config not found

**Solution:**
The tracker config is included with Ultralytics. If you get this error:
1. Ensure Ultralytics is properly installed
2. Or specify a custom tracker config path

## 🚀 Production Deployment

### For Server Deployment

Instead of running `app.py` directly, use a production server:

**Using Gunicorn (Linux/Mac):**
```bash
gunicorn -w 4 -b 0.0.0.0:5000 --timeout 600 app:app
```

**Using Waitress (Windows):**
```bash
waitress-serve --host=0.0.0.0 --port=5000 app:app
```

### Important for Production

1. **Change the SECRET_KEY** in `app.py`:
```python
app.config['SECRET_KEY'] = 'your-random-secret-key-here'
```

2. **Set DEBUG to False**:
```python
app.run(host="0.0.0.0", port=5000, debug=False)
```

3. **Set up automatic cleanup** for old files (already implemented)

4. **Consider using NGINX** as a reverse proxy

5. **Set up HTTPS** for secure connections

## 📊 Performance Optimization

### For Faster Processing:

1. **Use GPU** - 10-50x faster than CPU
2. **Use smaller model** - YOLOv8n is fastest
3. **Reduce IMGSZ** - 320 or 416 instead of 640
4. **Reduce confidence threshold** - Skip unnecessary computations

### For Better Accuracy:

1. **Use larger model** - YOLOv8x is most accurate
2. **Increase IMGSZ** - 1280 for maximum detail
3. **Increase confidence threshold** - Reduce false positives

## 🔐 Security Considerations

When deploying to a server:

1. **Limit file upload size** (already set to 500MB)
2. **Validate file types** (already implemented)
3. **Use HTTPS** in production
4. **Set up authentication** if needed
5. **Regular file cleanup** (already implemented)

## 📞 Support

If you encounter issues:

1. Check this guide first
2. Review the main `README.md`
3. Check Ultralytics documentation: https://docs.ultralytics.com/
4. Verify all dependencies are installed correctly

## ✅ Quick Checklist

Before running the app:

- [ ] Python 3.8+ installed
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] Model path configured in `app.py`
- [ ] Device setting configured (GPU or CPU)
- [ ] Model file (`.pt`) exists at specified path
- [ ] Port 5000 is available

You're all set! Run the application and start detecting! 🎉

---

**Need help? Check the main README.md or contact support.**

