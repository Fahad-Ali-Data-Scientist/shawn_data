# 🎯 YOLO Detection Web App

A professional, production-ready Flask web application for object detection using YOLO (You Only Look Once) with three powerful features:

1. **Image Detection** - Upload images and get instant object detection results
2. **Video Detection** - Process videos with frame-by-frame object detection
3. **Video Detection with Counting** - Track and count unique objects using ByteTrack

## ✨ Features

- 🎨 **Clean Professional UI** - Simple, modern design with professional blue color scheme
- 📊 **Real-time Progress Tracking** - See processing progress for video analysis
- 📈 **Object Counting** - Track unique objects across video frames using ByteTrack
- 💾 **Video Download** - Download processed videos with detections
- 📱 **Responsive Design** - Works perfectly on desktop and mobile devices
- ⚡ **Fast Processing** - Optimized for GPU acceleration

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Model Path

Open `app.py` and update the model path at the top:

```python
# ===================== CONFIGURATION =====================
MODEL_PATH = "path/to/your/best.pt"  # CHANGE THIS TO YOUR MODEL PATH
CONF_THRESHOLD = 0.25
IOU_THRESHOLD = 0.45
IMGSZ = 640
DEVICE = "0"  # Use "cpu" or "0" for GPU
# =========================================================
```

### 3. Run the Application

```bash
python app.py
```

The application will start on `http://localhost:5000`

## 📁 Project Structure

```
yolo/
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── README.md              # This file
├── templates/
│   └── index.html         # Web interface
├── static/
│   ├── css/
│   │   └── style.css      # Professional styling
│   └── js/
│       └── app.js         # JavaScript (reserved)
├── uploads/               # Temporary upload storage (auto-created)
├── outputs/               # Processed video outputs (auto-created)
├── SETUP_GUIDE.md         # Detailed setup instructions
├── QUICK_START.txt        # Quick reference guide
└── DESIGN_NOTES.md        # Design documentation
```

## 🎮 Usage

### Image Detection
1. Click on the **"Image Detection"** tab
2. Upload an image (JPG, PNG, JPEG)
3. Click **"Detect Objects"**
4. View results with bounding boxes and confidence scores

### Video Detection
1. Click on the **"Video Detection"** tab
2. Upload a video file (MP4, AVI, MOV)
3. Click **"Process Video"**
4. Watch real-time progress bar
5. View and download the processed video

### Detection with Counting
1. Click on the **"Detection with Counting"** tab
2. Upload a video file
3. Click **"Process with Counting"**
4. See real-time counting statistics
5. View the annotated video with unique object counts
6. Download the processed video

## ⚙️ Configuration Options

Edit these settings in `app.py`:

| Setting | Description | Default |
|---------|-------------|---------|
| `MODEL_PATH` | Path to your YOLO model weights | Required |
| `CONF_THRESHOLD` | Confidence threshold for detections | 0.25 |
| `IOU_THRESHOLD` | IoU threshold for NMS | 0.45 |
| `IMGSZ` | Input image size | 640 |
| `DEVICE` | Device to run inference on | "0" (GPU) |
| `MAX_CONTENT_LENGTH` | Maximum upload file size | 500MB |

## 🖥️ Production Deployment

### Using Gunicorn (Linux/Mac)

```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Using Waitress (Windows)

```bash
waitress-serve --host=0.0.0.0 --port=5000 app:app
```

### Docker Deployment (Optional)

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    libgl1-mesa-glx \
    libglib2.0-0 \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 5000

# Run with gunicorn
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

Build and run:

```bash
docker build -t yolo-detection-app .
docker run -p 5000:5000 yolo-detection-app
```

## 🔧 Troubleshooting

### Model Not Found Error
- Ensure `MODEL_PATH` in `app.py` points to your actual `.pt` file
- Use absolute path or correct relative path

### GPU Not Working
- Change `DEVICE = "0"` to `DEVICE = "cpu"` for CPU inference
- Ensure CUDA is properly installed for GPU usage

### Video Processing Too Slow
- Reduce `IMGSZ` to 416 or 320 for faster processing
- Use GPU if available
- Lower video resolution before upload

### Port Already in Use
- Change port in `app.run()` to a different number
- Or kill the process using port 5000

## 📊 Performance Tips

1. **Use GPU** - Set `DEVICE = "0"` for much faster processing
2. **Optimize Model Size** - Use YOLOv8n (nano) for speed, YOLOv8x for accuracy
3. **Adjust Image Size** - Smaller `IMGSZ` = faster but less accurate
4. **Batch Processing** - Process multiple frames at once (advanced)

## 🤝 Support

For issues or questions:
- Check the troubleshooting section above
- Review YOLO documentation: https://docs.ultralytics.com/
- Ensure all dependencies are correctly installed

## 📄 License

This project is provided as-is for educational and commercial use.

## 🎯 Features in Detail

### ByteTrack Object Tracking
- Uses state-of-the-art ByteTrack algorithm
- Assigns unique IDs to detected objects
- Tracks objects across frames
- Counts unique objects per class

### Real-time Progress Updates
- Frame-by-frame progress tracking
- Estimated time remaining
- Current frame count
- Live object count updates

### Clean Code Structure
- Simple and easy to understand
- Well-commented code
- Modular design
- Production-ready

---

**Built with ❤️ using Flask and Ultralytics YOLO**

