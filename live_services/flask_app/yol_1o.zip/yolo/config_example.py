# Example Configuration File
# Copy this to the top of app.py and modify as needed

# ===================== CONFIGURATION =====================

# MODEL CONFIGURATION
MODEL_PATH = "path/to/your/best.pt"  # REQUIRED: Path to your YOLO model

# DETECTION SETTINGS
CONF_THRESHOLD = 0.25    # Confidence threshold (0.0 - 1.0)
IOU_THRESHOLD = 0.45     # IoU threshold for NMS (0.0 - 1.0)
IMGSZ = 640             # Image size (320, 416, 640, 1280)

# DEVICE SETTINGS
DEVICE = "0"            # "cpu" for CPU, "0" for GPU 0, "0,1" for multiple GPUs

# SERVER SETTINGS
HOST = "0.0.0.0"        # "0.0.0.0" for all interfaces, "127.0.0.1" for localhost only
PORT = 5000             # Port number
DEBUG = True            # Set to False in production

# FILE UPLOAD SETTINGS
MAX_FILE_SIZE_MB = 500  # Maximum upload size in MB

# =========================================================

# COMMON CONFIGURATIONS:

# For CPU-only processing:
# DEVICE = "cpu"
# IMGSZ = 416

# For fast processing (lower quality):
# IMGSZ = 320
# CONF_THRESHOLD = 0.30

# For high accuracy (slower):
# IMGSZ = 1280
# CONF_THRESHOLD = 0.20

# For production server:
# DEBUG = False
# HOST = "0.0.0.0"

# For local testing only:
# HOST = "127.0.0.1"
# DEBUG = True

